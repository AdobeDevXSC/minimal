/**
 * the calculateMontlyPmt function takes amount, apr and years as input values
 * It returns a monthly payment amount based on the inputs
 * It leverages bootbox.js for error messaging
 */

function calculateMontlyPmt(amount, apr, years)
{

	var principal = amount;
	var interest = apr / 100 / 12;
	var payments = (years) * 12;

   // bootbox.alert("payment years = " + years + " interest = " + interest);

  	var x = Math.pow(1 + interest, payments); //Math.pow computes powers
	var monthly = (principal*x*interest)/(x-1);
   // var payAmt =0;


     //  var x = Math.pow(1 + interest, payments); //Math.pow computes powers
//var monthly = (principal*x*interest)/(x-1);


    if (isFinite(monthly)){
		var payAmt = monthly.toFixed(2);
    }
    else{
			 bootbox.alert("unable to calculate");
    }

    return payAmt;
}
