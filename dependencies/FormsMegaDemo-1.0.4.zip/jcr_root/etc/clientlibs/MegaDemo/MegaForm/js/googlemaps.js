

/**
 * the getAddrByZip returns the city state, country and zip for a given postal code
 * It uses the google maps API
 * postalCode is the postalCode string for the request
 * city, state, zip and country reference the som expressions for the associated fields in the adaptive form
 * they are used to populate the values back to adaptive form
 */

function getAddrByZip(postalCode, city, state, zip, country){

var outCity;
var outState;
var outCountry;

//Retrieves googleAPIKey from content fragment
var googleAPI = getGoogleAPIKey();

 var url = "https://maps.googleapis.com/maps/api/geocode/json?address=" + postalCode +  "&sensor=true&key=" + googleAPI;
//alert("key = " + googleAPI);
//var city ="";
//var state = "";
//var country = "";

    $.ajax({
        type: "POST",
        url: url,
        data: postalCode,
        async: false,
        success: function (resp) {
        //alert(resp.properties.elements.googleapikey.value);
        data=resp.results[0].formatted_address;
		//alert(resp.results[0].address_components.length);

           for(i=0;i<resp.results[0].address_components.length;i++)
        {
            var type = resp.results[0].address_components[i].types[0];

            if(type == "locality")
            {

                 guideBridge.resolveNode(city).value = resp.results[0].address_components[i].long_name;
            }

            if(type == "administrative_area_level_1")
            {

                 guideBridge.resolveNode(state).value = resp.results[0].address_components[i].long_name;
            }
            if(type == "country")
            {

                guideBridge.resolveNode(country).value = resp.results[0].address_components[i].short_name;

            }


      	}

   		 },
    	error: function () {}

        }); 



}

/**
 * the getGoogleAPIKey function retrieves the google api key stored in a content fragment
 * The content fragment is located at: "assets/aemformsdemo/formsdemokeys"
 * This must be configureed 
 * city, state, zip and country reference the som expressions for the associated fields in the adaptive form
 * they are used to populate the values back to adaptive form
 */

function getGoogleAPIKey() {
var data;
var baseurl = window.location.origin;
var responseString;
// used to reference the location of the content fragment
var cfUrl = baseurl + "/api/assets/megaformsdemo/megademoconfig.json";

$.ajax({
    url: cfUrl,
    data: '',
    async: false,
    success: function (resp) {

        data= resp.properties.elements.googleapikey.value;

    },
    error: function () {}
	}); 

    // ajax asynchronus request 
   // var json = JSON.parse(data);

    if(data == null){
		alert("Add your Google API Key to the 'content/dam/megaformsdemo/megademoconfig' content fragment.");
    }


return data; // return data from the ajax request
 }




/**
 * Uses free api https://restcountries.com
 * Returns array list of countycode-countrynames
 * Designed to be used in DropDown fields
 * Check to see if service is available before using
 */
function populateCountryDropDown(){
var data;
var countryArray= [];

$.ajax({
    url: 'https://restcountries.com/v2/all',
    data: '',
    async: false,
    success: function (resp) {


    for(i=0;i<resp.length;i++){

			var countryName = resp[i].name;
         	var countryCode =  resp[i].alpha2Code;

         var countryNameValue = (countryCode + "=" + countryName );

			countryArray.push(countryNameValue);
        }


    },
    error: function () {console.log("Country rest service is not available");}
	}); 


  
     return countryArray;
 }

