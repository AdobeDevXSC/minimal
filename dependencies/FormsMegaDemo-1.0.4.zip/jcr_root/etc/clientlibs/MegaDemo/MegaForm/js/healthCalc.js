
/**
 * the calculateBMIUS function takes the persons height in feet and inches and weight in pounds
 * It returns the BMI to the form
 */
function calculateBMIUS(feet, inches, weight){
		var BMI;
    	var feetInches  = feet * 12;
		var heightInInches = feetInches + inches;
     	var squaredHeight = Math.pow(heightInInches,2);
    	BMI  = (weight/squaredHeight) * 703;
    	return BMI;
}


function calcuDiabetesRisk(age, sex, gestD, famHist, bloodPressure, activity, BMI)
{
    var risk = 0;

		if(age == "")
            risk = risk +1;
    	if(sex =="Male")
            risk = risk + 1;
    	if(gestD =="Yes")
            risk = risk +1;
    	if(famHist == "Yes")
			risk= risk +1;
        if(bloodPressure == "Yes")
                risk= risk +1;
    	if(activity == "No")
                risk= risk +1;
   		 if(BMI > 1)
                risk= risk +1;

	var riskMsg;
    if(risk >4)
    {  
        riskMsg ="Your results indicate you have " + risk +  " risk factors for diabetes and that you may be at-risk.";

    }
    else if(risk <=4) {
		 riskMsg ="Your results indicate you have " + risk +  " risk factors for diabetes and you are not at-risk.";
    }

    return riskMsg;
}