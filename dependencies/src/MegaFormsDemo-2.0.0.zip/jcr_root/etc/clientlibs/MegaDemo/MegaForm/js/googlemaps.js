

/**
 * the getAddrByZip returns the city state, country and zip for a given postal code
 * If googleAPI key is available it using the Google Maps API
 * postalCode is the postalCode string for the request
 * city, state, zip and country reference the som expressions for the associated fields in the adaptive form
 * they are used to populate the values back to adaptive form
 *
 */

function getAddrByZip(postalCode, city, state, zip, country){

var outCity;
var outState;
var outCountry;

//Retrieves googleAPIKey from content fragment
var googleAPI = getGoogleAPIKey();

if(!googleAPI)
{
	//Uses zipwise.com/webservices/zipinfo.php Rest Web service
    populateFromZip(postalCode, city, state, country);
}
    else{
		//Uses google maps API
        getAddrByZipGoogle(postalCode, city, state, zip, country);
    }

}

/**
 * the getGoogleAPIKey function retrieves the google api key stored in a content fragment
 * The content fragment is located at: "assets/aemformsdemo/formsdemokeys"
 * This must be configureed 
 * city, state, zip and country reference the som expressions for the associated fields in the adaptive form
 * they are used to populate the values back to adaptive form
 */

function getGoogleAPIKey() {
var data;
var baseurl = window.location.origin;

// used to reference the location of the content fragment
var cfUrl = baseurl + "/api/assets/megaformsdemo/megademoconfig.json";

$.ajax({
    url: cfUrl,
    data: '',
    async: false,
    success: function (resp) {

        data= resp.properties.elements.googleapikey.value;

    },
    error: function () {}
	}); 


return data; // return data from the ajax request
 }


function hasAPI(){
var baseurl = window.location.origin;

// used to reference the location of the content fragment
var cfUrl = baseurl + "/api/assets/megaformsdemo/megademoconfig.json";

$.ajax({
    url: cfUrl,
    data: '',
    async: false,
    success: function (resp) {

        data= resp.properties.elements.googleapikey.value;

    },
    error: function () {}
	}); 
	if(data.length>0)
        return true;
    else
        return false;
}



/**
 * Uses free api https://restcountries.com
 * Returns array list of countycode-countrynames
 * Designed to be used in DropDown fields
 * Check to see if service is available before using
 */
function populateCountryDropDown(){
var data;
var countryArray= [];

$.ajax({
    url: 'https://restcountries.com/v2/all',
    data: '',
    async: false,
    success: function (resp) {


    for(i=0;i<resp.length;i++){

			var countryName = resp[i].name;
         	var countryCode =  resp[i].alpha2Code;

         var countryNameValue = (countryCode + "=" + countryName );

			countryArray.push(countryNameValue);
        }


    },
    error: function () {console.log("Country rest service is not available");}
	}); 


  
     return countryArray;
 }

function populateFromZip(postalCode, city, state, country)
{
	var restURL = "https://www.zipwise.com/webservices/zipinfo.php?key=8gqdrfa748bt89gf&zip=" + postalCode + "&format=json";

$.ajax({
    url: restURL,
    data: '',
    async: false,
    success: function (resp) {
        	guideBridge.resolveNode(city).value =resp.results.cities[0].city;
			guideBridge.resolveNode(state).value = resp.results.state;
        	guideBridge.resolveNode(country).value = "US";


    },
    error: function () {console.log("Service is not available");}
	}); 

}





/**
 * the getAddrByZipGoogle returns the city state, country and zip for a given postal code
 * It uses the google maps API and requires a google API Key
 * postalCode is the postalCode string for the request
 * city, state, zip and country reference the som expressions for the associated fields in the adaptive form
 * they are used to populate the values back to adaptive form
 *
 */

function getAddrByZipGoogle(postalCode, city, state, zip, country){

var outCity;
var outState;
var outCountry;

//Retrieves googleAPIKey from content fragment
var googleAPI = getGoogleAPIKey();
var url = "https://maps.googleapis.com/maps/api/geocode/json?address=" + postalCode +  "&sensor=true&key=" + googleAPI;


    $.ajax({
        type: "POST",
        url: url,
        data: postalCode,
        async: false,
        success: function (resp) {
        data=resp.results[0].formatted_address;

           for(i=0;i<resp.results[0].address_components.length;i++)
        {
            var type = resp.results[0].address_components[i].types[0];

            if(type == "locality")
            {

                 guideBridge.resolveNode(city).value = resp.results[0].address_components[i].long_name;
            }

            if(type == "administrative_area_level_1")
            {

                 guideBridge.resolveNode(state).value = resp.results[0].address_components[i].long_name;
            }
            if(type == "country")
            {

                guideBridge.resolveNode(country).value = resp.results[0].address_components[i].short_name;

            }


      	}

   		 },
    	error: function () {}

        }); 

}


function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else { 
    alert( "Geolocation is not supported by this browser.");
  }
}

function showPosition(position) {
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;
    var googleAPI = getGoogleAPIKey();
    if(googleAPI)
    {
	var url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=" + latitude+","+ longitude+"&key="+ googleAPI;

        $.getJSON(url,function (data, textStatus){
           
           var location=data.results[0].formatted_address;
           console.log(location);
            var streetNum;
            var streetName;
           for(i=0;i<data.results[0].address_components.length;i++)
               {
                 if(data.results[0].address_components[i].types[0] == "street_number" )
                   {

                    // streetNumber.value = data.results[0].address_components[i].long_name;
                       streetNum = data.results[0].address_components[i].long_name;
                   }
                 if(data.results[0].address_components[i].types[0] == "route")
                   {
        
                     //streetName.value = data.results[0].address_components[i].long_name;
                       streetName= data.results[0].address_components[i].long_name;
                   }
                    if(data.results[0].address_components[i].types[0] == "postal_code")
                   {
                       guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].borrowerInfo[0].address[0].zipCode[0]").value = data.results[0].address_components[i].long_name;
                   }
                   /*
                   if(data.results[0].address_components[i].types[0] == "locality")
                   {
        
                     city.value = data.results[0].address_components[i].long_name;
        
                   }
        
                 if(data.results[0].address_components[i].types[0] == "administrative_area_level_1")
                   {
        
                     state.value = data.results[0].address_components[i].long_name;
                   }*/
                  // streetAddr.value = streetNum  + " " + streetName;
                   guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].borrowerInfo[0].address[0].streetAddr[0]").value = streetNum  + " " + streetName;
        
               }
        
         });
    }

}
