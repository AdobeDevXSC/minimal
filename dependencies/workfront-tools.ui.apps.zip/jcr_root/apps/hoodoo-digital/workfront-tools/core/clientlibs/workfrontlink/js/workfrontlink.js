/* eslint no-useless-concat:0 */
(function(document, $) {
    "use strict";
    var activator = ".cq-damadmin-admin-workfront-link";
    var workfrontLink = "";

	$(document).ready(function(){
        $(activator).append("<coral-icon icon=\"/apps/hoodoo-digital/workfront-tools/core/clientlibs/assets/resources/workfront-icon.svg\" size=\"s\" style=\"float: left; width:18px\" class=\"workfront-icon\">");
    });
	
    $(document).on("foundation-contentloaded", function(e) {
        var contentPath = $('.cq-damadmin-admin-childpages').data('foundation-collection-id');

        $(activator).attr('hidden', 'hidden');

        $.ajax({
            url: contentPath + "/jcr:content/metadata/wfProjectURL",
            success: function(result) {
                if (result != "") {
                    $(activator).removeAttr('hidden');
                    workfrontLink = result;
                }
            }
        })
    });


    $(document).on("click", activator, function(e) {
        if(workfrontLink) {
            window.open(workfrontLink, '_blank');
        }
    });

})(document, Granite.$);